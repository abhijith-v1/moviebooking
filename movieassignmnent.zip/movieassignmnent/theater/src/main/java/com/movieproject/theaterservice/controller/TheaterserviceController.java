package com.movieproject.theaterservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.movieproject.theaterservice.Theater.Theater;



@RestController
public class TheaterserviceController {
	
	@Autowired
	private theaterservice Theaterservice;
	
	
	@RequestMapping(method=RequestMethod.GET, value="/getalltheaters")
	public List<Theater>getAllmovies(){
		return Theaterservice.getAlltheaters();
	}

	// Fetches details of a specific movie
			@RequestMapping(value = "/theater/{theaterName}/theaterdetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
			public ResponseEntity<List<Theater>> getMovieDetails(@PathVariable("theaterName") String moviename){
				return new ResponseEntity<>(Theaterservice.getTheaterDetails(moviename),HttpStatus.OK);
			}
			// adding new movie
			@RequestMapping(value = "/addTheater", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
			public ResponseEntity<Theater> addMovie(@Valid @RequestBody Theater theater){
				return new ResponseEntity<>(Theaterservice.addTheater(theater),HttpStatus.OK);
			}
			
			//update movie
			@RequestMapping(value = "/theater/update", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
		    public ResponseEntity<Theater> updateDetails(@Valid @RequestBody Theater theater){
		        return new ResponseEntity<>(Theaterservice.updateTheater(theater), HttpStatus.OK);
			}
			
			// delete movie by id
			@RequestMapping(value = "/theater/{theaterName}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
		    public ResponseEntity <Void> deleteUser(@PathVariable("theaterName") Integer id){
				Theaterservice.deleteByTheaterId(id);
		    return new ResponseEntity<Void>(HttpStatus.OK);
				
			}
			
}
