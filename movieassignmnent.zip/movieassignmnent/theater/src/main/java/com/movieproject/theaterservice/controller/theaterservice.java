package com.movieproject.theaterservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.movieproject.theaterservice.Theater.Theater;


@Service
public class theaterservice {

	@Autowired
	private TheaterRepository theaterRepository;
	
	public List<Theater> getAlltheaters(){
		 List<Theater> theaters=new ArrayList<>();
		 theaterRepository.findAll().forEach(theaters::add);
			return theaters;
		}
	
	public Theater addTheater(Theater theaters) {
		return theaterRepository.save(theaters);
	}
	
	public List<Theater> getTheaterDetails(String theatername)
	
	{
		return (List<Theater>) theaterRepository.findBytheatername(theatername);
		
	}
	
	public Theater updateTheater(Theater movie) {
		return theaterRepository.save(movie);
	}
	
	public void deleteByTheaterId(Integer id) {
		theaterRepository.deleteById(id);
	}
}
