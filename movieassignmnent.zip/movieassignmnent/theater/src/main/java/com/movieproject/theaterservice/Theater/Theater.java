package com.movieproject.theaterservice.Theater;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "theater")
public class Theater {

 	@Id
	private Integer theaterid;
 	private String theatername;
 	private String location;
 	private String capacity;
 	
 	public Theater()
 	{
 		
 	}
 	
 	public Theater(Integer theaterid, String theatername, String location, String capacity) {
		super();
		this.theaterid = theaterid;
		this.theatername = theatername;
		this.location = location;
		this.capacity = capacity;
 	}
	public Integer getTheaterid() {
		return theaterid;
	}
	public void setTheaterid(Integer theaterid) {
		this.theaterid = theaterid;
	}
			
	public String getTheatername() {
		return theatername;
	}
	public void setTheatername(String theatername) {
		this.theatername = theatername;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}

}
