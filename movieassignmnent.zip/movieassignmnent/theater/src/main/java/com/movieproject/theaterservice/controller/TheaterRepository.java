package com.movieproject.theaterservice.controller;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.movieproject.theaterservice.Theater.Theater;



@Repository
public interface TheaterRepository extends  CrudRepository<Theater, Integer> {
	
	public List<Theater> findBytheatername(String theatername);
	
}