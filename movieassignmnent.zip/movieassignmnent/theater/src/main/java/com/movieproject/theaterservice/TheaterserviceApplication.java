package com.movieproject.theaterservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TheaterserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TheaterserviceApplication.class, args);
	}

}
