package com.movieproject.bookingservice.Booking;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotNull;

import com.movieproject.bookingservice.Entities.Show;
import com.movieproject.bookingservice.Entities.User;



@Entity
public class Booking {
	
	@Id
    @Column(name="bookingid")
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Integer bookingid;

    @OneToOne
    private User userid;
    
    @OneToOne
    private Show showid;
    
    @NotNull
    private Integer seatsbooked;
    
    
    private Float amount;
    
    private String status;
    
    public Booking() {
        super();
    }

 

    public Integer getBookingId() {
        return bookingid;
    }

 

    public void setBookingId(Integer bookingid) {
        this.bookingid = bookingid;
    }

 

    public User getUserId() {
        return userid;
    }

 

    public void setUserId(User userid) {
        this.userid = userid;
    }
    
    public String getStatus() {
        return status;
    }

 

    public void setStatus(String status) {
        this.status = status;
    }

 

    
    public Show getShowid() {
        return showid;
    }

 

    public void setShowid(Show showid) {
        this.showid = showid;
    }

 

    public Integer getSeatsBooked() {
        return seatsbooked;
    }

 

    public void setSeatsBooked(Integer seatsbooked) {
        this.seatsbooked = seatsbooked;
    }

 

    public Float getAmount() {
        return amount;
    }

 

    public void setAmount(Float amount) {
        this.amount = amount;
    }
    

}
