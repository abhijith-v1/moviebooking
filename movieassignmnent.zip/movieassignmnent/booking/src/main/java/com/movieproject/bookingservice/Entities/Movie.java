package com.movieproject.bookingservice.Entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "movie")
public class Movie {

 	@Id
 	private Integer movieid;
 	private String moviename;
 	private String rating;
 	private String language;
 	
 	public Movie()
 	{
 		
 	}
 	
 	public Movie(Integer movieid, String moviename, String rating, String language) {
		super();
		this.movieid = movieid;
		this.moviename = moviename;
		this.rating = rating;
		this.language = language;
 	}
	public Integer getMovieid() {
		return movieid;
	}
	public void setMovieid(Integer movieid) {
		this.movieid = movieid;
	}
			
	public String getMoviename() {
		return moviename;
	}
	public void setMoviename(String moviename) {
		this.moviename = moviename;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
 	
}
