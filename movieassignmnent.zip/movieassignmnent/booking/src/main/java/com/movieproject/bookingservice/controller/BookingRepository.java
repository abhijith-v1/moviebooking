package com.movieproject.bookingservice.controller;

import org.springframework.data.repository.CrudRepository;

import com.movieproject.bookingservice.Booking.Booking;

public interface BookingRepository extends CrudRepository<Booking, Integer>  {

}
