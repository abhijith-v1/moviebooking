package com.movieproject.bookingservice.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import com.movieproject.bookingservice.Booking.Booking;
import com.movieproject.bookingservice.Entities.Show;

@Service
public class Bookingservice {
	

	@Autowired
	private BookingRepository bookingrepository;
	@Autowired
	private ShowRepository showrepository;
	
	
	
	public Booking addBooking(Booking booking) {
        Integer seatsBooked=booking.getSeatsBooked();
        Integer showid=booking.getShowid().getShowid();
        Optional <Show> show=showrepository.findById(showid);
        Float ticketPrice=show.get().getTicketprice();
        Integer seatsAvailable=show.get().getSeatsavailable();
        Integer remainingseats=seatsAvailable-seatsBooked;
        show.get().setSeatsavailable(remainingseats);
        System.out.println(remainingseats);
        System.out.println(ticketPrice);
        Float amount=(seatsBooked*ticketPrice);
        booking.setAmount(amount);
        booking.setStatus("BOOKED");
        return bookingrepository.save(booking);
    }
	
	
	
	public List<Booking> getBookingsbytdate(String fromDate,String toDate){
        List<Booking> allbookings= new ArrayList<>();
        List<Booking> bookinglist= new ArrayList<>();
        bookingrepository.findAll().forEach(allbookings::add);
       
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date startdate = null;
        Date enddate = null;
       
        try {
            startdate = dateFormat.parse(fromDate);
            enddate = dateFormat.parse(toDate);
        }
        catch (ParseException e) {
            e.printStackTrace();
        }
       
        for(Booking booking : allbookings){
           if(booking.getShowid().getShowdate().after(startdate)||booking.getShowid().getShowdate().before(enddate)||
                   booking.getShowid().getShowdate().equals(startdate)||booking.getShowid().getShowdate().equals(enddate)) {
               bookinglist.add(booking);
           }
        }
        return bookinglist;
       
    }

 

	
	public List<Booking> getBookings(){
		return (List<Booking>) bookingrepository.findAll();
	}
	
	public Booking getBookingbyId(Integer id) {
		return bookingrepository.findById(id).get();
	}
	
	public Booking deleteBooking(Integer id) {
		   
        Booking booking=getBookingbyId(id);
        Integer seatsBooked=booking.getSeatsBooked();
        Show show=booking.getShowid();
        Integer seatsAvailable=show.getSeatsavailable();
        Integer remainingSeats=(seatsAvailable+seatsBooked);
        System.out.println(remainingSeats);
        show.setSeatsavailable(remainingSeats);
        booking.setStatus("CANCELLED");
        return bookingrepository.save(booking);

    }
	
	public List<Show> getAllShows(){
        return (List<Show>) showrepository.findAll();
    }
    
    public Optional<Show> findShow(Integer id) {        
        Optional<Show> show = showrepository.findById(id);
        return show;
    }
    
    public Show addShow(Show show) {
    	System.out.println(show.getMovieid().getMovieid());
        return showrepository.save(show);
    }
    
    
    public Show updateshowDetails(Integer id,Show show) {
        show.setShowid(id);
        return showrepository.save(show);
    }
    
    public Show getShow(Integer id) {
		return showrepository.findById(id).get();
	}
    
    public void deleteShow(Integer id) {      
    	showrepository.deleteById(id);        
    }

    
    public List<Show> findShowByMoive(Integer movieId) {       
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
            if(show.getMovieid().getMovieid().equals(movieId)) {
                shows.add(show);
            }
        }
        return shows;     
    }
    
    public List<Show> findShowByTheatre(Integer theatreId) {       
        List<Show> allshows = getAllShows();
        List<Show> shows = new ArrayList<>();
        for(Show show : allshows) {
            if(show.getTheatreId().getTheaterid().equals(theatreId)) {
                shows.add(show);
            }
        }
        return shows;     
    }


}
