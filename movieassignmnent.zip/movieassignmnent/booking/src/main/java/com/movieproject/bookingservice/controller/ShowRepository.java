package com.movieproject.bookingservice.controller;

import org.springframework.data.repository.CrudRepository;

import com.movieproject.bookingservice.Entities.Show;

public interface ShowRepository extends CrudRepository<Show, Integer> {

}
