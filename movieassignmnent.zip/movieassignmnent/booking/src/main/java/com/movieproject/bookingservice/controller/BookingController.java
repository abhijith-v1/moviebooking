package com.movieproject.bookingservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.movieproject.bookingservice.Booking.Booking;
import com.movieproject.bookingservice.Entities.Show;




@RestController
public class BookingController {

	@Autowired
	private Bookingservice bookingservice;
	
	//adding new show

	@PostMapping(value ="/addshow")
	public ResponseEntity<Show> addShow(@RequestBody Show show) {
		return new ResponseEntity<>(bookingservice.addShow(show),HttpStatus.OK);
	}
	//showing all shows available
	
	@GetMapping(value ="/Allshows")
	public ResponseEntity<List<Show>> getShows(){
		return new ResponseEntity<>(bookingservice.getAllShows(),HttpStatus.OK);
	}
	// show details by show id
	
	@GetMapping(value ="/show/{id}")
    public ResponseEntity<Show> getShowById(@PathVariable("id") Integer id){
        return new ResponseEntity<>(bookingservice.getShow(id),HttpStatus.OK);
    }
	
	// show details by movie id
	
	@GetMapping(path = "/getshow/{movieId}")
	   public ResponseEntity<List<Show>> findShowByMoive(@PathVariable("movieId") Integer movieId){
	       return new ResponseEntity<>(bookingservice.findShowByMoive(movieId),HttpStatus.OK);
	   }
	
	//show details by theater id
	@GetMapping(path = "/getshowbytheatre/{theatreId}")
	   public ResponseEntity<List<Show>> findShowByTheatre(@PathVariable("theatreId") Integer theatreId){
	       return new ResponseEntity<>(bookingservice.findShowByTheatre(theatreId),HttpStatus.OK);
	   }
      
    // updating a show details
    @RequestMapping(method=RequestMethod.PUT, value="/updateshow/{id}")
    public ResponseEntity<Show> updateDetails(@PathVariable("id") Integer id,@Valid @RequestBody Show show){
        return new ResponseEntity<>(bookingservice.updateshowDetails(id, show), HttpStatus.OK);
    }
    
    // delete show by show id
    @DeleteMapping(path = "/show/{id}")
    public ResponseEntity <Void> deleteShow(@PathVariable("id") Integer id){
    	bookingservice.deleteShow(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
        
    }
	// booking 
    @PostMapping(value ="/addbooking")
    public ResponseEntity<Booking> addBooking(@Valid @RequestBody Booking booking) throws Exception {
        try {
        return new ResponseEntity<>(bookingservice.addBooking(booking),HttpStatus.OK);
        }
        catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage(), e);
        }
    }
	// shows all booking
	@GetMapping(value ="/Allbooking")
	public ResponseEntity<List<Booking>> getBooking(){
		return new ResponseEntity<>(bookingservice.getBookings(),HttpStatus.OK);
	}
	
	// shows booking for a specified period
	
	 @GetMapping(path = "/getbooking/{fromDate}/{toDate}")
	   public ResponseEntity<List<Booking>> getBookings(@PathVariable("fromDate") String fromDate,@PathVariable("toDate") String toDate){
	       return new ResponseEntity<>(bookingservice.getBookingsbytdate(fromDate,toDate),HttpStatus.OK);
	   }
	 //cancel booking
	
	@DeleteMapping(path = "/cancelbooking/{id}")
    public ResponseEntity <Void> cancelBooking(@PathVariable("id") Integer id){
		bookingservice.deleteBooking(id);
    return new ResponseEntity<Void>(HttpStatus.OK);
        
    }
}
