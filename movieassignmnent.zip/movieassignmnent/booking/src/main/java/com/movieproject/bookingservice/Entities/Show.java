package com.movieproject.bookingservice.Entities;

import java.sql.Date;
import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;



@Entity
@Table(name = "showtable")
public class Show {

	@Id
	@Column(name = "id")        	    
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer showid;
	
	@OneToOne
	private Movie movieid;	
    
	@OneToOne
	private Theater theatreid;
	
	@NotNull
	private float ticketprice;

	private Date showdate;

	//private Time showTime;
	
	@NotNull
	private int seatsavailable;
	
	
	
	public Show() {
		super();
	}
	
	public Movie getMovieid() {
		return movieid;
	}

	public void setMovieid(Movie movieid) {
		this.movieid = movieid;
	}
	
	public Integer getShowid() {
		return showid;
	}

	public void setShowid(Integer showid) {
		this.showid = showid;
	}


	public Theater getTheatreId() {
		return theatreid;
	}

	public void setTheatreid(Theater theatreid) {
		this.theatreid = theatreid;
	}

	public float getTicketprice() {
		return ticketprice;
	}

	public void setTicketprice(float ticketprice) {
		this.ticketprice = ticketprice;
	}

	public Date getShowdate() {
		return showdate;
	}

	public void setShowdate(Date showdate) {
		this.showdate = showdate;
	}

//	public Time getShowTime() {
//		return showTime;
//	}
//
//	public void setShowTime(Time showTime) {
//		this.showTime = showTime;
//	}

	public int getSeatsavailable() {
		return seatsavailable;
	}

	public void setSeatsavailable(int seatsavailable) {
		this.seatsavailable = seatsavailable;
	}	

}

