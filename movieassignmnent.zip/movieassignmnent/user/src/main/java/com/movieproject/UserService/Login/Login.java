package com.movieproject.UserService.Login;

public class Login {

	private String Name;
	private String Password;
	private String Role;

	public Login() {
		
	}
	
	public Login(String Name, String Password, String Role) {
		super();
		this.Name = Name;
		this.Password = Password;
		this.Role = Role;
	}

	public String getName() {
		return Name;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String Password) {
		this.Password = Password;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String Role) {
		this.Role = Role;
	}

}
