package com.movieproject.UserService.Controller;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.movieproject.UserService.User.User;


@Repository
public interface TopicRepository extends  CrudRepository<User, String>{

}
