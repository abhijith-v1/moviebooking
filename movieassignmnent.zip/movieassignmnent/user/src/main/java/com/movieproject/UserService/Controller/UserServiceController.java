package com.movieproject.UserService.Controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.movieproject.UserService.Login.Login;
import com.movieproject.UserService.User.User;


@RestController
public class UserServiceController {
	
	@Autowired
	private userservice Userservice;
	@Autowired
    private TopicRepository topicreporsitory;
	
	//login
	
	
    
	@RequestMapping(method=RequestMethod.GET, value="/admin/user")
	public List<User>getAllusers(){
		
		return Userservice.getAllusers();
	}
	
	
//	@PostMapping("/ADMIN")
//	 public User user(@RequestBody User user)
//	 
//	 {
//		System.out.println("got user name"+ user.getName());
//		//Userservice.addUser(user);
//		//User newuser= topicreporsitory.save(user);
//		return Userservice.addUser(user);
//	 }
	
	// register
	
	@RequestMapping(method=RequestMethod.POST,value="/ADMIN")
	public void adduser(@RequestBody User user) {

		Userservice.addUser(user);
	} 
	
	@DeleteMapping(path = "/admin/{Userid}")
	public void deleteuserdetails(@PathVariable String Userid) {
		Userservice.delete(Userid);
	}
	
	@RequestMapping( method=RequestMethod.POST, value="/login")
    public ResponseEntity<String> login(@Valid @RequestBody Login loginuser){
         return new ResponseEntity<>(Userservice.login(loginuser), HttpStatus.OK);
       
    }
	
}

