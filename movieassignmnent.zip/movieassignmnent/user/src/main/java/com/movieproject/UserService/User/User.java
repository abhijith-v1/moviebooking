package com.movieproject.UserService.User;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User {

	   // @Id
	  //  @GeneratedValue(strategy=GenerationType.AUTO)
	   // private int Userid;
	    @Id
	    @Column(name="name")
	    private String Name;
	    @Column(name="email")
	    private String Email;
	    @Column(name="phonenumber")
	    private String Phonenumber;
	    @Column(name="password")
	    private String Password;
	    @Column(name="role")
	    private String Role;
	    
	    public User() {
	    	
	    }
	    
	    
	    public User( String Name, String Email, String Phonenumber, String Password, String Role) {
	        super();
	        //this.Userid = Userid;
	        this.Name = Name;
	        this.Email = Email;
	        this.Phonenumber = Phonenumber;
	        this.Password = Password;
	        this.Role = Role;
	    }
	 
//	    public int getuserid() {
//	        return Userid;
//	    }
//	 
//	    public void setuserid(int Userid) {
//	        this.Userid = Userid;
//	    }
	 
	    public String getName() {
	        return Name;
	    }
	 
	    public void setName(String Name) {
	        this.Name = Name;
	    }
	    
	    public String getEmail() {
	        return Email;
	    }
	 
	    public void setEmail(String Email) {
	        this.Email = Email;
	    }
	    public String getPhoneNumber() {
	        return Phonenumber;
	    }
	 
	    public void setPhoneNumber(String Phonenumber) {
	        this.Phonenumber = Phonenumber;
	    }
	    public String getPassword() {
	        return Password;
	    }
	 
	    public void setPassword(String Password) {
	        this.Password = Password;
	    }
	    
	    public String getRole() {
	        return Role;
	    }
	 
	    public void setRole(String Role) {
	        this.Role = Role;
	    }
}
