package com.movieproject.UserService.Controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieproject.UserService.Login.Login;
import com.movieproject.UserService.User.User;



@Service
public class userservice {
	
	@Autowired
	private TopicRepository topicRepository;
	
	public List<User> getAllusers(){
	 List<User> users=new ArrayList<>();
	 topicRepository.findAll().forEach(users::add);
		return users;
	}
	
	
	public User addUser(User user) {
		User user1 = new User();
		//User1.setuserid(User.getuserid());
		user1.setName(user.getName());
		user1.setEmail(user.getEmail());
		user1.setPhoneNumber(user.getPhoneNumber());
		user1.setPassword(user.getPassword());
		user1.setRole(user.getRole());
		
		topicRepository.save(user1);
		return user1;
	}

	public void delete(String Userid)
	{
		topicRepository.deleteById(Userid);
	}
	
	  public String login(Login loginuser)
	    {
	        User user=null;
	        Optional <User> optuser=topicRepository.findById(loginuser.getName());
	       
	    if(optuser.isPresent()) {
	            user=optuser.get();
	            if(user.getPassword().equals(loginuser.getPassword())) {
	                return "successfully login";
	            }
	           
	            else {
	                return "failed login";
	               
	            }
	    }
	            else {
	            return "No user present";
	            }
	        }
}

