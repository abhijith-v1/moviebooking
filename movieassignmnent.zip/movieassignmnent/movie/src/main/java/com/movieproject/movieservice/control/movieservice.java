package com.movieproject.movieservice.control;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movieproject.movieservice.Movie.Movie;



@Service
public class movieservice {

	@Autowired
	private MovieRepository movieRepository;
	
	
	public List<Movie> getAllmovies(){
		 List<Movie> movies=new ArrayList<>();
		 movieRepository.findAll().forEach(movies::add);
			return movies;
		}
	
	public Movie addMovie(Movie movie) {
		return movieRepository.save(movie);
	}
	
	public List<Movie> getMovieDetails(String moviename)
	
	{
		return (List<Movie>) movieRepository.findBymoviename(moviename);
		
	}
	
	public Movie updateMovie(Movie movie) {
		return movieRepository.save(movie);
	}
	
	public void deleteByMovieId(Integer id) {
		movieRepository.deleteById(id);
	}
}
