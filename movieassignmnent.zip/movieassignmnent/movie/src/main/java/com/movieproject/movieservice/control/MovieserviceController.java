package com.movieproject.movieservice.control;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.movieproject.movieservice.Movie.Movie;

@RestController
public class MovieserviceController {
	
	@Autowired
	private movieservice Movieservice;
	
		
    // show all movies
	
	@RequestMapping(method=RequestMethod.GET, value="/allmovies")
	public List<Movie>getAllmovies(){
		
		return Movieservice.getAllmovies();
	}
	
	// Fetches details of a specific movie
		@RequestMapping(value = "/movie/{movieName}/moviedetails", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<List<Movie>> getMovieDetails(@PathVariable("movieName") String moviename){
			return new ResponseEntity<>(Movieservice.getMovieDetails(moviename),HttpStatus.OK);
		}
		
		// adding new movie
		@RequestMapping(value = "/movie/newmovie", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<Movie> addMovie(@Valid @RequestBody Movie movie){
			return new ResponseEntity<>(Movieservice.addMovie(movie),HttpStatus.OK);
		}
		
		//update movie
		@RequestMapping(value = "/movie/{}", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity<Movie> updateDetails(@Valid @RequestBody Movie movie){
	        return new ResponseEntity<>(Movieservice.updateMovie(movie), HttpStatus.OK);
		}
		
		// delete movie by id
		@RequestMapping(value = "/movie/{id}", method = RequestMethod.DELETE, produces = MediaType.APPLICATION_JSON_VALUE)
	    public ResponseEntity <Void> deleteMovie(@PathVariable("id") Integer id){
	    Movieservice.deleteByMovieId(id);
	    return new ResponseEntity<Void>(HttpStatus.OK);
			
		}
		

		
}
